package com.ellstudiosapp.kamussederhana;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class KamusModel {
    @SerializedName("kamus")
    private List<KamusItem> kamus;

    public List<KamusItem> getKamus() {
        return kamus;
    }

    public static class KamusItem {
        private int id;
        private String indonesia;
        private String lampung;

        public int getId() {
            return id;
        }

        public String getIndonesia() {
            return indonesia;
        }

        public String getLampung() {
            return lampung;
        }
    }
}
