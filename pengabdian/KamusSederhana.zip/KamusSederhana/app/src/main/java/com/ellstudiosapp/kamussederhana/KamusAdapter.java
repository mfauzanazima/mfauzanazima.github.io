package com.ellstudiosapp.kamussederhana;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class KamusAdapter extends RecyclerView.Adapter<KamusAdapter.KamusViewHolder> {

    private List<KamusModel.KamusItem> kamusList;
    private List<KamusModel.KamusItem> kamusListFull;

    public KamusAdapter(List<KamusModel.KamusItem> kamusList) {
        this.kamusList = kamusList;
        this.kamusListFull = new ArrayList<>(kamusList);
    }

    @NonNull
    @Override
    public KamusViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_kamus, parent, false);
        return new KamusViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull KamusViewHolder holder, int position) {
        KamusModel.KamusItem item = kamusList.get(position);
        holder.tvIndonesia.setText(item.getIndonesia());
        holder.tvLampung.setText(item.getLampung());
    }

    @Override
    public int getItemCount() {
        return kamusList.size();
    }

    public void updateData(List<KamusModel.KamusItem> newList) {
        this.kamusList = newList;
        this.kamusListFull = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    public void filter(String text) {
        List<KamusModel.KamusItem> filteredList = new ArrayList<>();
        if (text.isEmpty()) {
            filteredList.addAll(kamusListFull);
        } else {
            text = text.toLowerCase().trim();
            for (KamusModel.KamusItem item : kamusListFull) {
                if (item.getIndonesia().toLowerCase().contains(text) ||
                        item.getLampung().toLowerCase().contains(text)) {
                    filteredList.add(item);
                }
            }
        }
        kamusList = filteredList;
        notifyDataSetChanged();
    }

    static class KamusViewHolder extends RecyclerView.ViewHolder {
        TextView tvIndonesia, tvLampung;

        public KamusViewHolder(@NonNull View itemView) {
            super(itemView);
            tvIndonesia = itemView.findViewById(R.id.tvIndonesia);
            tvLampung = itemView.findViewById(R.id.tvLampung);
        }
    }
}
